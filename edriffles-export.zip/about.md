---
title: about
slug: about
published_date: 2026-08-10T20:16:00+00:00
publish: true
make_discoverable: false
is_page: true
class_name: photo-post
---

I'm Ty or Ed